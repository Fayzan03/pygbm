#base_simulator.py is the module that contains the class GBMSimulator
#this is the correct syntax
from .base_simulator import GBMSimulator
