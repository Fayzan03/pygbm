# pygbm Package

Simulates Geometric Brownian Motion 

## Features

Initialise a GBM siimulator
return t, Y values that can be plotted

## Installation

<description of the installation>

## Usage

<baseline example of usage>

## Documentation

Link to the [documentation page](https://your-readthedocs-url-here).

## Contributing

Contributions via pull requests are welcome!

## License

<description of the license>